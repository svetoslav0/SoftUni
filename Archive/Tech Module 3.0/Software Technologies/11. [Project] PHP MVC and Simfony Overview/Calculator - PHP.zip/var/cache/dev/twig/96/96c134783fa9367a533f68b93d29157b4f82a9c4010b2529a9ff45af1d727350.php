<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e30e7a2f9ceee89dde9a9f3210f77b2a1dd8b63a268672ac3379c533cf76819 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e30e7a2f9ceee89dde9a9f3210f77b2a1dd8b63a268672ac3379c533cf76819->enter($__internal_5e30e7a2f9ceee89dde9a9f3210f77b2a1dd8b63a268672ac3379c533cf76819_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_aa2d96936395dc1dc4e2c7df26f263b1f7c372865b84c2f8ce88b2c6aa38941b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa2d96936395dc1dc4e2c7df26f263b1f7c372865b84c2f8ce88b2c6aa38941b->enter($__internal_aa2d96936395dc1dc4e2c7df26f263b1f7c372865b84c2f8ce88b2c6aa38941b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5e30e7a2f9ceee89dde9a9f3210f77b2a1dd8b63a268672ac3379c533cf76819->leave($__internal_5e30e7a2f9ceee89dde9a9f3210f77b2a1dd8b63a268672ac3379c533cf76819_prof);

        
        $__internal_aa2d96936395dc1dc4e2c7df26f263b1f7c372865b84c2f8ce88b2c6aa38941b->leave($__internal_aa2d96936395dc1dc4e2c7df26f263b1f7c372865b84c2f8ce88b2c6aa38941b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_869070d39f50463756be7141855ceb532076ade5f52c0efff24b45082e08ca69 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_869070d39f50463756be7141855ceb532076ade5f52c0efff24b45082e08ca69->enter($__internal_869070d39f50463756be7141855ceb532076ade5f52c0efff24b45082e08ca69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_52381acde4d3eda73526d7931ef10290d6abcf135675e84f18390736a15c9cbf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52381acde4d3eda73526d7931ef10290d6abcf135675e84f18390736a15c9cbf->enter($__internal_52381acde4d3eda73526d7931ef10290d6abcf135675e84f18390736a15c9cbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_52381acde4d3eda73526d7931ef10290d6abcf135675e84f18390736a15c9cbf->leave($__internal_52381acde4d3eda73526d7931ef10290d6abcf135675e84f18390736a15c9cbf_prof);

        
        $__internal_869070d39f50463756be7141855ceb532076ade5f52c0efff24b45082e08ca69->leave($__internal_869070d39f50463756be7141855ceb532076ade5f52c0efff24b45082e08ca69_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_784c5d4aeefbe028ffb153c6e3f02c14b4c4d607826745704dca8ad354bfc484 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_784c5d4aeefbe028ffb153c6e3f02c14b4c4d607826745704dca8ad354bfc484->enter($__internal_784c5d4aeefbe028ffb153c6e3f02c14b4c4d607826745704dca8ad354bfc484_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_b651531ee59cb11659ff9a82a51ca0e5afda63f6b05fb31b428f2a4333e42107 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b651531ee59cb11659ff9a82a51ca0e5afda63f6b05fb31b428f2a4333e42107->enter($__internal_b651531ee59cb11659ff9a82a51ca0e5afda63f6b05fb31b428f2a4333e42107_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_b651531ee59cb11659ff9a82a51ca0e5afda63f6b05fb31b428f2a4333e42107->leave($__internal_b651531ee59cb11659ff9a82a51ca0e5afda63f6b05fb31b428f2a4333e42107_prof);

        
        $__internal_784c5d4aeefbe028ffb153c6e3f02c14b4c4d607826745704dca8ad354bfc484->leave($__internal_784c5d4aeefbe028ffb153c6e3f02c14b4c4d607826745704dca8ad354bfc484_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_01498651a9f972799679ea6edfad61eeac4c5c063b95dd55c6518a6bc6c4b420 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01498651a9f972799679ea6edfad61eeac4c5c063b95dd55c6518a6bc6c4b420->enter($__internal_01498651a9f972799679ea6edfad61eeac4c5c063b95dd55c6518a6bc6c4b420_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_54884db61339522f94dfe5fe33fe53fba91b339b21591b5a079c5a7b7e95e317 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54884db61339522f94dfe5fe33fe53fba91b339b21591b5a079c5a7b7e95e317->enter($__internal_54884db61339522f94dfe5fe33fe53fba91b339b21591b5a079c5a7b7e95e317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_54884db61339522f94dfe5fe33fe53fba91b339b21591b5a079c5a7b7e95e317->leave($__internal_54884db61339522f94dfe5fe33fe53fba91b339b21591b5a079c5a7b7e95e317_prof);

        
        $__internal_01498651a9f972799679ea6edfad61eeac4c5c063b95dd55c6518a6bc6c4b420->leave($__internal_01498651a9f972799679ea6edfad61eeac4c5c063b95dd55c6518a6bc6c4b420_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "E:\\Calculator - PHP\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
