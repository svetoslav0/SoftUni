<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8fc34b97a9bffe7ac6dc2ac4edcf336a13c17ce9f8321a486df05623280ab1ba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8fc34b97a9bffe7ac6dc2ac4edcf336a13c17ce9f8321a486df05623280ab1ba->enter($__internal_8fc34b97a9bffe7ac6dc2ac4edcf336a13c17ce9f8321a486df05623280ab1ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_49b533d9993bb32806bf6ea23a60beaa7bab0ba48babd351bccf340bdd10e35f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49b533d9993bb32806bf6ea23a60beaa7bab0ba48babd351bccf340bdd10e35f->enter($__internal_49b533d9993bb32806bf6ea23a60beaa7bab0ba48babd351bccf340bdd10e35f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_8fc34b97a9bffe7ac6dc2ac4edcf336a13c17ce9f8321a486df05623280ab1ba->leave($__internal_8fc34b97a9bffe7ac6dc2ac4edcf336a13c17ce9f8321a486df05623280ab1ba_prof);

        
        $__internal_49b533d9993bb32806bf6ea23a60beaa7bab0ba48babd351bccf340bdd10e35f->leave($__internal_49b533d9993bb32806bf6ea23a60beaa7bab0ba48babd351bccf340bdd10e35f_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_da5dd7caad64fa71abc841c4a160e7203c211273484959722507be9ea29cc28d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_da5dd7caad64fa71abc841c4a160e7203c211273484959722507be9ea29cc28d->enter($__internal_da5dd7caad64fa71abc841c4a160e7203c211273484959722507be9ea29cc28d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_a1fbe4efe58501fa2a80f694fdd38e199d6ba284f0f605d28b677d7b57c0882a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1fbe4efe58501fa2a80f694fdd38e199d6ba284f0f605d28b677d7b57c0882a->enter($__internal_a1fbe4efe58501fa2a80f694fdd38e199d6ba284f0f605d28b677d7b57c0882a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_a1fbe4efe58501fa2a80f694fdd38e199d6ba284f0f605d28b677d7b57c0882a->leave($__internal_a1fbe4efe58501fa2a80f694fdd38e199d6ba284f0f605d28b677d7b57c0882a_prof);

        
        $__internal_da5dd7caad64fa71abc841c4a160e7203c211273484959722507be9ea29cc28d->leave($__internal_da5dd7caad64fa71abc841c4a160e7203c211273484959722507be9ea29cc28d_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a3e7d7e140882fb7a05824a66590bb06fb27d4ca2e109e188b7529fdef362d3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3e7d7e140882fb7a05824a66590bb06fb27d4ca2e109e188b7529fdef362d3b->enter($__internal_a3e7d7e140882fb7a05824a66590bb06fb27d4ca2e109e188b7529fdef362d3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_38adeda8e7b41f18fdfa7ca47df372780f3ed58a065e84530887c28d9c06ec4c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38adeda8e7b41f18fdfa7ca47df372780f3ed58a065e84530887c28d9c06ec4c->enter($__internal_38adeda8e7b41f18fdfa7ca47df372780f3ed58a065e84530887c28d9c06ec4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_38adeda8e7b41f18fdfa7ca47df372780f3ed58a065e84530887c28d9c06ec4c->leave($__internal_38adeda8e7b41f18fdfa7ca47df372780f3ed58a065e84530887c28d9c06ec4c_prof);

        
        $__internal_a3e7d7e140882fb7a05824a66590bb06fb27d4ca2e109e188b7529fdef362d3b->leave($__internal_a3e7d7e140882fb7a05824a66590bb06fb27d4ca2e109e188b7529fdef362d3b_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_10519854fa37493ce361a646a87f73e7b1367ba566944875edbd4691c56415f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10519854fa37493ce361a646a87f73e7b1367ba566944875edbd4691c56415f0->enter($__internal_10519854fa37493ce361a646a87f73e7b1367ba566944875edbd4691c56415f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_38458fb8353c6b00bdc39802199d69ffb8fb58170ddfe9950ffb465f66a05533 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38458fb8353c6b00bdc39802199d69ffb8fb58170ddfe9950ffb465f66a05533->enter($__internal_38458fb8353c6b00bdc39802199d69ffb8fb58170ddfe9950ffb465f66a05533_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_38458fb8353c6b00bdc39802199d69ffb8fb58170ddfe9950ffb465f66a05533->leave($__internal_38458fb8353c6b00bdc39802199d69ffb8fb58170ddfe9950ffb465f66a05533_prof);

        
        $__internal_10519854fa37493ce361a646a87f73e7b1367ba566944875edbd4691c56415f0->leave($__internal_10519854fa37493ce361a646a87f73e7b1367ba566944875edbd4691c56415f0_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_4474b81efcf2f26fe2cfb608be0ae785b8ff3862a9561236dd1c7647e3148ee9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4474b81efcf2f26fe2cfb608be0ae785b8ff3862a9561236dd1c7647e3148ee9->enter($__internal_4474b81efcf2f26fe2cfb608be0ae785b8ff3862a9561236dd1c7647e3148ee9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_7d419084d4afcad7700d6427c25ca6c10d9c42f4016019b9a1aecf392767b2bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d419084d4afcad7700d6427c25ca6c10d9c42f4016019b9a1aecf392767b2bc->enter($__internal_7d419084d4afcad7700d6427c25ca6c10d9c42f4016019b9a1aecf392767b2bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_7d419084d4afcad7700d6427c25ca6c10d9c42f4016019b9a1aecf392767b2bc->leave($__internal_7d419084d4afcad7700d6427c25ca6c10d9c42f4016019b9a1aecf392767b2bc_prof);

        
        $__internal_4474b81efcf2f26fe2cfb608be0ae785b8ff3862a9561236dd1c7647e3148ee9->leave($__internal_4474b81efcf2f26fe2cfb608be0ae785b8ff3862a9561236dd1c7647e3148ee9_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_4469a457246f5d2c0119c3da078197a53148a83469b9004d8c6868cc684531b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4469a457246f5d2c0119c3da078197a53148a83469b9004d8c6868cc684531b3->enter($__internal_4469a457246f5d2c0119c3da078197a53148a83469b9004d8c6868cc684531b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ebf9eb90d2a1800116a0b792c053e138c296da0a9624bb4bd65ca770f7da9945 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ebf9eb90d2a1800116a0b792c053e138c296da0a9624bb4bd65ca770f7da9945->enter($__internal_ebf9eb90d2a1800116a0b792c053e138c296da0a9624bb4bd65ca770f7da9945_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_ebf9eb90d2a1800116a0b792c053e138c296da0a9624bb4bd65ca770f7da9945->leave($__internal_ebf9eb90d2a1800116a0b792c053e138c296da0a9624bb4bd65ca770f7da9945_prof);

        
        $__internal_4469a457246f5d2c0119c3da078197a53148a83469b9004d8c6868cc684531b3->leave($__internal_4469a457246f5d2c0119c3da078197a53148a83469b9004d8c6868cc684531b3_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_f634ea0b6fe34b52b62894ddb900a4b028f06f1a491a2098462ce3fd836ee32d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f634ea0b6fe34b52b62894ddb900a4b028f06f1a491a2098462ce3fd836ee32d->enter($__internal_f634ea0b6fe34b52b62894ddb900a4b028f06f1a491a2098462ce3fd836ee32d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_97a73a356c105dfbd2621df3efdf371a4ce3555fa6c8f3228bf65d2f6c878d09 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97a73a356c105dfbd2621df3efdf371a4ce3555fa6c8f3228bf65d2f6c878d09->enter($__internal_97a73a356c105dfbd2621df3efdf371a4ce3555fa6c8f3228bf65d2f6c878d09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_97a73a356c105dfbd2621df3efdf371a4ce3555fa6c8f3228bf65d2f6c878d09->leave($__internal_97a73a356c105dfbd2621df3efdf371a4ce3555fa6c8f3228bf65d2f6c878d09_prof);

        
        $__internal_f634ea0b6fe34b52b62894ddb900a4b028f06f1a491a2098462ce3fd836ee32d->leave($__internal_f634ea0b6fe34b52b62894ddb900a4b028f06f1a491a2098462ce3fd836ee32d_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_84662ebfeb2f12e60221edee4d6119a95efe85fa02aab2bb48ff7fb8bb04be2f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84662ebfeb2f12e60221edee4d6119a95efe85fa02aab2bb48ff7fb8bb04be2f->enter($__internal_84662ebfeb2f12e60221edee4d6119a95efe85fa02aab2bb48ff7fb8bb04be2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_85e3cbe64516e8c84588bfe09930a720f9e8fb0540d6d19633309d90fe50a8a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_85e3cbe64516e8c84588bfe09930a720f9e8fb0540d6d19633309d90fe50a8a7->enter($__internal_85e3cbe64516e8c84588bfe09930a720f9e8fb0540d6d19633309d90fe50a8a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_85e3cbe64516e8c84588bfe09930a720f9e8fb0540d6d19633309d90fe50a8a7->leave($__internal_85e3cbe64516e8c84588bfe09930a720f9e8fb0540d6d19633309d90fe50a8a7_prof);

        
        $__internal_84662ebfeb2f12e60221edee4d6119a95efe85fa02aab2bb48ff7fb8bb04be2f->leave($__internal_84662ebfeb2f12e60221edee4d6119a95efe85fa02aab2bb48ff7fb8bb04be2f_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_a00e7890c1e9fbb3a7bdf967888b10618ef0a09f3e2e1d2620b4d00e0ceb5b59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a00e7890c1e9fbb3a7bdf967888b10618ef0a09f3e2e1d2620b4d00e0ceb5b59->enter($__internal_a00e7890c1e9fbb3a7bdf967888b10618ef0a09f3e2e1d2620b4d00e0ceb5b59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_adfdd630c97a6c560b772f153ad9f9fe8b6fe631cbe66995cfd51e66280a7f22 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_adfdd630c97a6c560b772f153ad9f9fe8b6fe631cbe66995cfd51e66280a7f22->enter($__internal_adfdd630c97a6c560b772f153ad9f9fe8b6fe631cbe66995cfd51e66280a7f22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_adfdd630c97a6c560b772f153ad9f9fe8b6fe631cbe66995cfd51e66280a7f22->leave($__internal_adfdd630c97a6c560b772f153ad9f9fe8b6fe631cbe66995cfd51e66280a7f22_prof);

        
        $__internal_a00e7890c1e9fbb3a7bdf967888b10618ef0a09f3e2e1d2620b4d00e0ceb5b59->leave($__internal_a00e7890c1e9fbb3a7bdf967888b10618ef0a09f3e2e1d2620b4d00e0ceb5b59_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "E:\\Calculator - PHP\\app\\Resources\\views\\base.html.twig");
    }
}
