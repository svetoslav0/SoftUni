module.exports = {
    errorGet: (req, res) => {
        res.redirect('/error/error');
    }

};